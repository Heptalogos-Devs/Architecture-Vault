# 文档目录

## 文档规则

- [文档职责与权威](DOCUMENT_MODEL.md)：规定 Vault 与代码仓库的文档所有权。

## Nous Wave

- [文档入口](Nous-Wave/README.md)：目标设计正文与各知识类别入口。
- [目标设计正文](Nous-Wave/TARGET_DESIGN.md)：唯一直接编辑的 Nous Wave Target Design Authority。
- [设计决定](Nous-Wave/DECISIONS.md)
- [未决问题](Nous-Wave/OPEN_QUESTIONS.md)
- [设计论证目录](Nous-Wave/rationale/README.md)
- [查询寻址与准备](Nous-Wave/rationale/10-query-addressing-and-preparation.md)
- [时间、概念与查询](Nous-Wave/rationale/11-temporal-concept-query.md)
- [认知、形成依据与模型执行](Nous-Wave/rationale/12-cognition-basis-model-execution.md)
- [研究与实验目录](Nous-Wave/research/README.md)
- [VCP 与联想检索算法谱系](Nous-Wave/research/VCP_AND_ASSOCIATIVE_LINEAGE.md)

## Heptalogos

- [文档入口](Heptalogos/README.md)：目标设计、决定、未决问题与论证。
- [目标设计正文](Heptalogos/TARGET_DESIGN.md)：唯一直接编辑的 Heptalogos 目标设计 Authority。
- [设计决定](Heptalogos/DECISIONS.md)
- [未决问题](Heptalogos/OPEN_QUESTIONS.md)
- [设计论证目录](Heptalogos/rationale/README.md)

## 跨系统与仓库职责

- [认知与主动性合同](integration/cognition-agency.md)：共享主体身份、认知输入、主动追求、行为权限和结果回传。
- [仓库组织模型](repository-governance/REPOSITORY_MODEL.md)：代码仓库、设计仓库与报告仓库的职责边界。
